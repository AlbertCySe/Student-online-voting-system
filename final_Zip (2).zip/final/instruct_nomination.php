<html>
<style>
button {   
       background-color: Purple;   
       width: 20%;  
        color: orange;   
        padding: 10px;    
        border: none;   
        cursor: pointer;  
padding: 16px 8px;  
  margin: 50px 1100;   
  cursor: pointer;  
  width: 10%;  
  opacity: 0.9;  
    }   
p {
  display: block;
  color: Teal;
  text-indent: 90px;
</style>
<body>
<center><h1 style="font-size:50px;"><b>
St.Joseph's College,Tiruchirappalli.</b></h1></center>
<center><h2>Department Of Computer</h2></center>
<h3>Instructions for Nomination:</h3>
<b><p>Nominate candidates are kindly follow the given instructions</p>
<p>1. Please fill the form carefully.</p>
<p>2. If you have above 60 percentage of CGPA,you will allow to apply the nomination.</p>
<p>3. If you don't have above 60 percentage of CGPA,you will never allow to apply the nomination.</p>
<p>4. If you have any arrears, you will not allow to apply the nomination.</p>
<p>5. If you have any complaints in your name in your department,you will not able to apply the nomination.</p>
<p>6. One main representative and one assistant representative and need three supporter's D.NO in the nomination form.</p>
<p>7. 31/03/2023 is the last date for nomination.</p> </b>
<form method="get" action="nomination.php">
<div><div><button type="next">Next</button></div></div>
</body>
</html>