<html>
<head>
<body>
<h3>This software is developed and tested by 20UCS604<h3>
<h2 style="text-align:center;font-family:algerian;font-size:300%;">St.Joseph's College , Tiruchirappalli</h2>
<h2 style="text-align:center;font-family:'Brush Script MT', cursive;font-size:250%;">Department Of Computer Science</h2>
<h2 style="text-align:center;font-family:'Brush Script MT', cursive;font-size:250%;">Online Voting - 2023</h2>
<center>
For any issue or problem contact 
          Email: sjcvotinghelp@gmail.com  
</html>
</head>
</body>