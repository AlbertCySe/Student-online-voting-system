<html>
<head>
<style>
button {   
       background-color: Purple;   
       width: 20%;  
        color: orange;   
        padding: 10px;    
        border: none;   
        cursor: pointer;  
padding: 16px 8px;  
  margin: 50px 1100;   
  cursor: pointer;  
  width: 10%;  
  opacity: 0.9;  
    }   



p {
  display: block;
  color: Teal;
  text-indent: 90px;
  
}
</style>
</head>
<body>
<center><h1 style="font-size:50px;"><b>
St.Joseph's College,Tiruchirappalli.</b></h1></center>
<center><h2>Department Of Computer</h2></center>
<h3>Instructions for Voting:</h3>
<b><p>Students are kindly follow the given instructions carefully</p>
<p>Step 1: Enter your department no and date of birth after click the 'Log In' button.</p>
<p>Step 2: Enter your college mail id and click the 'Send OTP' button.</p>
<p>Step 3: The OTP has been sent your college mail id so open new tab in your browser.</p>
<p>Step 4: Open your college mail id and copy the OTP and put into the OTP box, after click the 'Verify OTP' button.</p>
<p>Step 5: The voting page has been displayed.</p>
<p>Step 6: Click the radio button to select your choice of representative after click the 'Submit' button.</p>
<p>Step 7: Fill out the Remark box and click the 'Submit' button.</p></b>
<form method="get" action="student_login.php">
<div><div><button type="next">Next</button></div></div>
</form>
</body>
</html>