<html>
<head>
<title>Home Page</title>
<style>
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: Gainsboro;
 background-attachment: fixed;  
 background-size: cover;
}  
button {   
       background-color: Purple;   
       width: 20%;  
        color: orange;   
        padding: 10px;    
        border: none;   
        cursor: pointer;  
padding: 16px 8px;  
  margin: 50px 1100;   
  cursor: pointer;  
  width: 10%;  
  opacity: 0.9;  
    }   
</style>
<body>
<h2 style="text-align:center;font-family:algerian;font-size:300%;">St.Joseph's College , Tiruchirappalli</h2>
<h2 style="text-align:center;font-family:'Brush Script MT', cursive;font-size:250%;">Department Of Computer Science</h2>
<h2 style="text-align:center;font-family:'Brush Script MT', cursive;font-size:250%;">Online Voting - 2021</h2>
<br>
<h2 style="text-align:center;font-family:'Brush Script MT', cursive;font-size:350%;">* Successfully Votted *</h2>	
<script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
<lord-icon
    src="https://cdn.lordicon.com/xxdqfhbi.json"
    trigger="hover"
    style="width:250px;height:250px">
</lord-icon>
<form method="get" action="student_login.php">
<div><div><button type="next">Logout</button></div></div>

</body>
</html>